# AngelV1

A transparent, consent-based Android parental monitoring app. The child always knows monitoring is active — a persistent notification shows "Guardian is active" at all times.

## Phase 1 (this build) — Core

- One-time permission setup wizard on first launch
- Set dashboard password
- Background foreground service (auto-start on boot)
- Web dashboard served from the APK (NanoHTTPD)
- Password-protected login page
- Device info: name, Android version, battery level, uptime, IP address
- Auto-restart on boot via `BootReceiver`
- Notification listener stub (Phase 2)

## Build the APK (no local setup needed)

1. Fork this repo on GitHub
2. Push any change to `main`
3. GitHub Actions builds the APK automatically (~5–7 min)
4. Download from **Actions → latest run → Artifacts → AngelV1-debug**

## Tech stack

| Part | Tech |
|------|------|
| Language | Kotlin |
| Min Android | 8.0 (SDK 26) |
| Target Android | 14 (SDK 34) |
| HTTP server | NanoHTTPD 2.3.3 |
| Remote access | Tailscale |
| Build | GitHub Actions v4, Java 17 |
| Dashboard UI | Single HTML file in APK assets |

## First launch flow

1. Welcome → permission wizard (all permissions granted once)
2. Set dashboard password
3. App minimises → Guardian service starts
4. Open any browser → `http://<phone-ip>:8080` → log in

## Remote access (from anywhere)

1. Install [Tailscale](https://tailscale.com) on both phone and PC
2. Use the Tailscale IP instead of the local Wi-Fi IP
3. Dashboard URL stays the same — `http://<tailscale-ip>:8080`

## Roadmap

| Phase | Features |
|-------|---------|
| **1 (done)** | Core service, permissions, web dashboard, device info |
| **2** | Live GPS, notifications mirror, app usage, file browser |
| **3** | Remote lock, screenshot, send SMS, kill/block apps |
| **4** | Screen mirror, camera snapshot, camera stream, microphone |

## License

MIT — personal / family use tool. Built for parents monitoring their own child on their own device with the child's knowledge.
