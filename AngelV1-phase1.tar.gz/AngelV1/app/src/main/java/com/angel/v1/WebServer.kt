package com.angel.v1

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONObject
import java.io.InputStream

class WebServer(private val context: Context) : NanoHTTPD(PORT) {

    companion object {
        const val TAG = "WebServer"
        const val PORT = 8080
        private const val SESSION_COOKIE = "angel_session"
        // Sessions stored in memory — cleared on service restart
        private val sessions = mutableSetOf<String>()
    }

    private val prefs = AppPrefs(context)

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        val method = session.method

        Log.d(TAG, "${method.name} $uri")

        return try {
            when {
                // Static dashboard HTML
                uri == "/" || uri == "/index.html" -> serveDashboard(session)

                // Auth
                uri == "/api/login" && method == Method.POST -> handleLogin(session)
                uri == "/api/logout" && method == Method.POST -> handleLogout(session)

                // Protected API endpoints — require valid session
                uri.startsWith("/api/") -> {
                    if (!isAuthenticated(session)) {
                        jsonResponse(Status.UNAUTHORIZED, mapOf("error" to "Unauthorized"))
                    } else {
                        routeProtectedApi(uri, method, session)
                    }
                }

                else -> newFixedLengthResponse(Status.NOT_FOUND, MIME_PLAINTEXT, "Not Found")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling $uri: ${e.message}", e)
            jsonResponse(Status.INTERNAL_ERROR, mapOf("error" to "Internal server error"))
        }
    }

    private fun serveDashboard(session: IHTTPSession): Response {
        return try {
            val html = context.assets.open("dashboard.html").bufferedReader().readText()
            newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read dashboard.html", e)
            newFixedLengthResponse(Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Dashboard not found")
        }
    }

    private fun handleLogin(session: IHTTPSession): Response {
        val body = mutableMapOf<String, String>()
        try {
            session.parseBody(body)
        } catch (_: Exception) {}

        // Parse JSON body
        val bodyStr = body["postData"] ?: ""
        val password = try {
            JSONObject(bodyStr).getString("password")
        } catch (_: Exception) {
            ""
        }

        val storedHash = prefs.dashboardPasswordHash
        if (storedHash.isEmpty()) {
            return jsonResponse(Status.INTERNAL_ERROR, mapOf("error" to "No password configured"))
        }

        return if (SecurityUtils.verifyPassword(password, storedHash)) {
            val token = SecurityUtils.generateSessionToken()
            sessions.add(token)
            val response = jsonResponse(Status.OK, mapOf("ok" to true))
            response.addHeader("Set-Cookie",
                "$SESSION_COOKIE=$token; Path=/; HttpOnly; SameSite=Strict")
            response
        } else {
            Thread.sleep(500) // Slow down brute force
            jsonResponse(Status.UNAUTHORIZED, mapOf("error" to "Invalid password"))
        }
    }

    private fun handleLogout(session: IHTTPSession): Response {
        val token = getSessionToken(session)
        if (token != null) sessions.remove(token)
        val response = jsonResponse(Status.OK, mapOf("ok" to true))
        response.addHeader("Set-Cookie",
            "$SESSION_COOKIE=; Path=/; HttpOnly; Max-Age=0")
        return response
    }

    private fun routeProtectedApi(uri: String, method: Method, session: IHTTPSession): Response {
        return when (uri) {
            "/api/device-info" -> {
                val info = DeviceInfo.toJson(context)
                newFixedLengthResponse(Status.OK, "application/json", info.toString())
            }
            "/api/notifications" -> {
                // Phase 2: return cached notifications from NotificationListener
                val list = NotificationListener.recentNotifications
                val arr = org.json.JSONArray()
                list.take(50).forEach { n ->
                    arr.put(JSONObject().apply {
                        put("pkg", n.packageName)
                        put("title", n.title)
                        put("text", n.text)
                        put("time", n.timestamp)
                    })
                }
                newFixedLengthResponse(Status.OK, "application/json", arr.toString())
            }
            else -> newFixedLengthResponse(Status.NOT_FOUND, MIME_PLAINTEXT, "Not Found")
        }
    }

    private fun isAuthenticated(session: IHTTPSession): Boolean {
        val token = getSessionToken(session) ?: return false
        return sessions.contains(token)
    }

    private fun getSessionToken(session: IHTTPSession): String? {
        val cookieHeader = session.headers["cookie"] ?: return null
        return cookieHeader.split(";")
            .map { it.trim() }
            .firstOrNull { it.startsWith("$SESSION_COOKIE=") }
            ?.removePrefix("$SESSION_COOKIE=")
            ?.trim()
    }

    private fun jsonResponse(status: Status, data: Map<String, Any>): Response {
        val json = JSONObject(data).toString()
        val response = newFixedLengthResponse(status, "application/json", json)
        response.addHeader("Access-Control-Allow-Origin", "*")
        response.addHeader("Cache-Control", "no-cache")
        return response
    }
}
