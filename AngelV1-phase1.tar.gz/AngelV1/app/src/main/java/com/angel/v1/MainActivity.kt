package com.angel.v1

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.angel.v1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppPrefs

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateBatteryDisplay(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)

        // First launch → go through wizard
        if (!prefs.setupComplete) {
            startActivity(Intent(this, PermissionWizardActivity::class.java))
            finish()
            return
        }

        setupUI()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.setupComplete) {
            updateStatusUI()
            updateDeviceInfo()
            registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
    }

    private fun setupUI() {
        updateDeviceInfo()
        updateStatusUI()

        binding.btnStartStop.setOnClickListener {
            if (AngelService.isRunning) {
                stopGuardian()
            } else {
                startGuardian()
            }
        }

        binding.btnOpenDashboard.setOnClickListener {
            val ip = NetworkUtils.getLocalIpAddress(this)
            if (ip != null) {
                val url = "http://$ip:${WebServer.PORT}"
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                startActivity(intent)
            } else {
                Toast.makeText(this, "No Wi-Fi connection detected", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnChangePassword.setOnClickListener {
            showChangePasswordDialog()
        }
    }

    private fun startGuardian() {
        val intent = Intent(this, AngelService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        updateStatusUI()
        Toast.makeText(this, "Guardian started", Toast.LENGTH_SHORT).show()
    }

    private fun stopGuardian() {
        AlertDialog.Builder(this)
            .setTitle("Stop Guardian?")
            .setMessage("The dashboard will be inaccessible and monitoring will stop. Are you sure?")
            .setPositiveButton("Stop") { _, _ ->
                stopService(Intent(this, AngelService::class.java))
                updateStatusUI()
                Toast.makeText(this, "Guardian stopped", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateStatusUI() {
        val running = AngelService.isRunning
        val ip = NetworkUtils.getLocalIpAddress(this)

        if (running) {
            binding.statusDot.setBackgroundResource(R.drawable.dot_running)
            binding.tvStatus.text = getString(R.string.status_running)
            binding.tvStatusDetail.text = if (ip != null)
                "Dashboard available at http://$ip:${WebServer.PORT}"
            else
                "Running — connect to Wi-Fi for dashboard access"
            binding.btnStartStop.text = "Stop Guardian"
            binding.tvLocalUrl.text = if (ip != null) "http://$ip:${WebServer.PORT}" else "—"
        } else {
            binding.statusDot.setBackgroundResource(R.drawable.dot_stopped)
            binding.tvStatus.text = getString(R.string.status_stopped)
            binding.tvStatusDetail.text = "Tap start to activate Guardian"
            binding.btnStartStop.text = "Start Guardian"
            binding.tvLocalUrl.text = "—"
        }

        binding.btnOpenDashboard.isEnabled = running && ip != null
    }

    private fun updateDeviceInfo() {
        binding.tvDeviceName.text = "${Build.MANUFACTURER} ${Build.MODEL}"
        binding.tvAndroidVersion.text = "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})"
        // Battery updated via broadcast receiver
        val batteryStatus = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (batteryStatus != null) {
            updateBatteryDisplay(batteryStatus)
        }
    }

    private fun updateBatteryDisplay(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        binding.tvBattery.text = if (pct >= 0) {
            "$pct%${if (isCharging) " (charging)" else ""}"
        } else {
            "Unknown"
        }
    }

    private fun showChangePasswordDialog() {
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "New password"
        }
        AlertDialog.Builder(this)
            .setTitle("Change Dashboard Password")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pwd = input.text.toString().trim()
                if (pwd.length >= 4) {
                    prefs.dashboardPasswordHash = SecurityUtils.hashPassword(pwd)
                    Toast.makeText(this, "Password updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Password must be at least 4 characters", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
