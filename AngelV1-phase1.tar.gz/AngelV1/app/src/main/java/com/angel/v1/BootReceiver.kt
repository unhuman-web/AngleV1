package com.angel.v1

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log

class BootReceiver : BroadcastReceiver() {

    companion object {
        const val TAG = "BootReceiver"
        // Delay start to let system fully boot
        const val BOOT_DELAY_MS = 5000L
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.i(TAG, "Received: $action")

        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != "android.intent.action.LOCKED_BOOT_COMPLETED" &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val prefs = AppPrefs(context)
        if (!prefs.setupComplete) {
            Log.i(TAG, "Setup not complete, skipping auto-start")
            return
        }

        if (prefs.dashboardPasswordHash.isEmpty()) {
            Log.i(TAG, "No password set, skipping auto-start")
            return
        }

        Log.i(TAG, "Scheduling Guardian start in ${BOOT_DELAY_MS}ms")

        // Use goAsync to keep the BroadcastReceiver alive during the delay
        val pendingResult = goAsync()

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val serviceIntent = Intent(context, AngelService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
                Log.i(TAG, "Guardian service started after boot")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start service on boot: ${e.message}", e)
            } finally {
                pendingResult.finish()
            }
        }, BOOT_DELAY_MS)
    }
}
