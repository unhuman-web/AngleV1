package com.angel.v1

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Notification mirror — Phase 2 feature.
 * Captures all device notifications and makes them available via the web dashboard.
 * This stub activates the service binding; full implementation is Phase 2.
 */
class NotificationListener : NotificationListenerService() {

    companion object {
        const val TAG = "NotificationListener"

        // Thread-safe list of recent notifications (max 100)
        private val notifications = ArrayDeque<NotificationData>(100)
        val recentNotifications: List<NotificationData> get() = notifications.toList()

        fun clearNotifications() = notifications.clear()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return

        // Skip our own notifications
        if (pkg == "com.angel.v1") return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        Log.d(TAG, "Notification from $pkg: $title")

        val data = NotificationData(
            packageName = pkg,
            title = title,
            text = text,
            timestamp = sbn.postTime
        )

        synchronized(notifications) {
            notifications.addFirst(data)
            if (notifications.size > 100) notifications.removeLast()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // No-op for Phase 1
    }
}

data class NotificationData(
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long
)
