package com.angel.v1

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

class AngelService : Service() {

    companion object {
        const val TAG = "AngelService"
        const val CHANNEL_ID = "angel_guardian_channel"
        const val NOTIFICATION_ID = 1001
        @Volatile var isRunning = false
    }

    private var webServer: WebServer? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "AngelService created")
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i(TAG, "AngelService starting")

        val notification = buildNotification()
        startForeground(NOTIFICATION_ID, notification)

        if (webServer == null || !webServer!!.isAlive) {
            webServer = WebServer(this)
            try {
                webServer!!.start()
                Log.i(TAG, "WebServer started on port ${WebServer.PORT}")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start WebServer: ${e.message}", e)
            }
        }

        isRunning = true

        // Update notification with current IP
        updateNotification()

        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "AngelService destroying")
        webServer?.stop()
        webServer = null
        isRunning = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Auto-restart when app removed from recents
        val restartIntent = Intent(applicationContext, AngelService::class.java)
        restartIntent.setPackage(packageName)
        val pendingIntent = PendingIntent.getService(
            this, 1, restartIntent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
        alarmManager.set(
            android.app.AlarmManager.ELAPSED_REALTIME,
            android.os.SystemClock.elapsedRealtime() + 2000,
            pendingIntent
        )
        super.onTaskRemoved(rootIntent)
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_desc)
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val tapIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val ip = NetworkUtils.getLocalIpAddress(this)
        val subtitle = if (ip != null)
            "Dashboard: http://$ip:${WebServer.PORT}"
        else
            "Guardian is active"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.guardian_active))
            .setContentText(subtitle)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(tapIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification())
    }
}
