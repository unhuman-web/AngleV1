package com.angel.v1

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import org.json.JSONObject

object DeviceInfo {

    fun toJson(context: Context): JSONObject {
        val batteryIntent = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val uptimeMs = SystemClock.elapsedRealtime()
        val uptimeSecs = uptimeMs / 1000
        val hours = uptimeSecs / 3600
        val minutes = (uptimeSecs % 3600) / 60

        val ip = NetworkUtils.getLocalIpAddress(context)

        return JSONObject().apply {
            put("deviceName", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("brand", Build.BRAND)
            put("model", Build.MODEL)
            put("androidVersion", Build.VERSION.RELEASE)
            put("sdkInt", Build.VERSION.SDK_INT)
            put("batteryLevel", batteryPct)
            put("batteryCharging", isCharging)
            put("uptimeHours", hours)
            put("uptimeMinutes", minutes)
            put("uptimeFormatted", "${hours}h ${minutes}m")
            put("localIp", ip ?: "unknown")
            put("port", WebServer.PORT)
            put("timestamp", System.currentTimeMillis())
        }
    }
}
