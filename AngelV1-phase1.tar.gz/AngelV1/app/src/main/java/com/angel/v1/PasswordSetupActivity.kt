package com.angel.v1

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.angel.v1.databinding.ActivityPasswordSetupBinding

class PasswordSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPasswordSetupBinding
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPasswordSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPrefs(this)

        binding.btnFinish.setOnClickListener {
            handleFinish()
        }
    }

    private fun handleFinish() {
        val password = binding.etPassword.text?.toString()?.trim() ?: ""
        val confirm = binding.etPasswordConfirm.text?.toString()?.trim() ?: ""

        when {
            password.length < 4 -> {
                showError("Password must be at least 4 characters")
            }
            password != confirm -> {
                showError("Passwords do not match")
            }
            else -> {
                // Save hashed password
                prefs.dashboardPasswordHash = SecurityUtils.hashPassword(password)
                prefs.setupComplete = true

                // Start the Guardian service
                val serviceIntent = Intent(this, AngelService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }

                Toast.makeText(this, "Guardian is now active!", Toast.LENGTH_SHORT).show()

                // Go to MainActivity
                val mainIntent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(mainIntent)
                finish()
            }
        }
    }

    private fun showError(msg: String) {
        binding.tvError.text = msg
        binding.tvError.visibility = android.view.View.VISIBLE
    }
}
