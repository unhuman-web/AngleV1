package com.angel.v1

import android.content.Context

class AppPrefs(context: Context) {

    private val prefs = context.getSharedPreferences("angel_prefs", Context.MODE_PRIVATE)

    var setupComplete: Boolean
        get() = prefs.getBoolean("setup_complete", false)
        set(v) = prefs.edit().putBoolean("setup_complete", v).apply()

    var dashboardPasswordHash: String
        get() = prefs.getString("dashboard_password_hash", "") ?: ""
        set(v) = prefs.edit().putString("dashboard_password_hash", v).apply()

    var sessionToken: String
        get() = prefs.getString("session_token", "") ?: ""
        set(v) = prefs.edit().putString("session_token", v).apply()

    // Screen capture MediaProjection token persistence
    var mediaProjectionResultCode: Int
        get() = prefs.getInt("mp_result_code", -999)
        set(v) = prefs.edit().putInt("mp_result_code", v).apply()

    fun clearSession() {
        prefs.edit().remove("session_token").apply()
    }
}
