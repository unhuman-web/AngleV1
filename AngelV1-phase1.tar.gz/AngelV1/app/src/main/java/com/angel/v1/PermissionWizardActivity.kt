package com.angel.v1

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.angel.v1.databinding.ActivityPermissionWizardBinding

class PermissionWizardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionWizardBinding

    private val requiredPermissions = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.READ_MEDIA_IMAGES)
            add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.READ_SMS)
    }

    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            onPermissionsGranted()
        } else {
            val denied = results.filterValues { !it }.keys
            Toast.makeText(
                this,
                "Some permissions were denied: ${denied.joinToString(", ") { it.substringAfterLast('.') }}\nGuardian may not work fully.",
                Toast.LENGTH_LONG
            ).show()
            // Still allow continuing — guardian works with partial permissions
            onPermissionsGranted()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionWizardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGrantAll.setOnClickListener {
            requestAllPermissions()
        }

        binding.btnNext.setOnClickListener {
            goToPasswordSetup()
        }

        checkCurrentPermissions()
    }

    private fun requestAllPermissions() {
        permissionsLauncher.launch(requiredPermissions.toTypedArray())

        // Battery optimisation — requires separate system intent
        requestBatteryOptimisationExemption()

        // Notification access (for notification mirror) — requires Settings
        requestNotificationListenerAccess()
    }

    private fun requestBatteryOptimisationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                // Fallback: open battery settings
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (_: Exception) {}
            }
        }
    }

    private fun requestNotificationListenerAccess() {
        val enabledListeners = Settings.Secure.getString(
            contentResolver, "enabled_notification_listeners"
        )
        if (enabledListeners == null || !enabledListeners.contains(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Exception) {}
        }
    }

    private fun onPermissionsGranted() {
        checkCurrentPermissions()
        binding.btnNext.isEnabled = true
    }

    private fun checkCurrentPermissions() {
        val granted = requiredPermissions.count { perm ->
            ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
        }
        val total = requiredPermissions.size
        if (granted == total) {
            binding.btnNext.isEnabled = true
        }
    }

    private fun goToPasswordSetup() {
        startActivity(Intent(this, PasswordSetupActivity::class.java))
        finish()
    }
}
