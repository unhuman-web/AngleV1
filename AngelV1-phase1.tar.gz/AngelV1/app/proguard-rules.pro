# NanoHTTPD
-keep class fi.iki.elonen.** { *; }
# Keep AngelV1 service classes
-keep class com.angel.v1.** { *; }
